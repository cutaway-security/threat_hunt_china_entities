# Verified Windows Indicators Dataset

## Overview
This dataset contains only **verified, non-inferred Windows indicators**.

## Files
- verified_windows_indicators.csv: detection artifacts
- verified_indicator_attribution.csv: reference mapping

## Indicator Types
- FILE_NAME
- FILE_PATH
- DLL_NAME
- SERVICE_NAME
- REGISTRY_KEY

## Methodology
- Zero speculation
- Evidence-based only
- Windows scope only

## Correlation Model
Indicators -> Software -> Company (via attribution file)

## Coverage Result
Only a subset of vendors produce Windows-detectable artifacts.
