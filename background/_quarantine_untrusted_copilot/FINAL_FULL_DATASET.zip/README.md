# Full Dataset Bundle

## Overview
This dataset provides a normalized relational dataset linking companies, aliases, relationships, software, indicators, and coverage.

## Files
- companies.csv: master entity list
- aliases.csv: alternate names
- relationships.csv: linkages
- software.csv: identified software
- indicators.csv: detection artifacts
- company_coverage.csv: completeness tracking

## Relationships
- companies -> software (via vendor_company_id)
- software -> indicators (via software_id)
- companies -> aliases
- companies -> relationships (parent/child)

## Coverage
All companies assigned:
- identified
- partial
- none

## Usage
Supports SIEM ingestion, threat hunting, enrichment, and detection engineering.
